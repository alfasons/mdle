<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'report_tuteur', language 'ar', version '4.0'.
 *
 * @package     report_tuteur
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['printmode'] = 'قابل للطباعة';
$string['selecteur_help'] = 'يمكنك اختيار النشاط الذي تريد إشرافه<br/>

* تحقق من النشاط
* ثم انقر زر المرشح

<H2>قواعد الألوان</h2>
<p>التعيين</p>
* برتقالي: التعيين مسلم ولكنه غير مُقَيّم أو فيه إفادة بعد
* أخضر: أخر تعيين تم تقييمه أو تقديم إفادته
<p>الاختبار</p>
* برتقالي: آخر محاولة ليست لها إفادة
* أخضر: سؤال واحد على الأقل من المحاولة الأخيرة لديه إفادة
<p>المذكرة</p>
* برتقالي: كتب الطالب شيئًا ما بدون تقييم أو إفادة
* أخضر: المذكرة مقيمة أو أن الطالب&quote;المقالة الأخيرة لديها رد
<p>الدرس</p>
* برتقالي: إنشاء بدون إفادة
* أخضر: كل الإنشاءات لديها إفادة

بمعنى أن اللون البرتقالي يتطلب إجراءً من قبل المدرس.';
$string['student-report'] = 'تقرير الطالب';
