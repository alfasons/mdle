<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'activitymap', language 'ar', version '4.0'.
 *
 * @package     activitymap
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['activity_from_other_section'] = 'هذا النشاط هو من قسم آخر';
$string['activitymapsettings'] = 'إعدادات خارطة النشاطات';
$string['after'] = 'بعد';
$string['allSections'] = 'كل الأقسام';
$string['allSectionsGrouped'] = 'كل الأقسام مجموعة';
$string['and'] = 'أيضاً';
$string['before'] = 'قبل';
$string['between'] = 'بين';
$string['box'] = 'صندوق';
$string['condition_AND_label'] = '&';
$string['condition_OR_label'] = '>=1';
$string['content'] = 'محتوى';
$string['currentSection'] = 'القسم الحالي';
$string['days_from_now'] = 'أيام بدءً من الآن';
$string['folder'] = 'مجلد';
$string['higher'] = 'أعلى من';
$string['line'] = 'خط';
$string['lower'] = 'أقل من';
$string['modulename'] = 'خارطة النشاطات';
$string['modulenameplural'] = 'خرائط النشاطات';
$string['none'] = 'لا أحد';
$string['note'] = 'ملاحظة';
$string['page-mod-url-x'] = 'أي صفحة لوحدة خارطة النشاط';
$string['pluginadministration'] = 'إدارة وحدة خارطة النشاطات';
$string['pluginname'] = 'خارطة النشاطات';
$string['printintro'] = 'عرض وصف خارطة النشاطات';
$string['printintroexplain'] = 'أتريد عرض الوصف أسفل المحتوى؟ بعض أنواع العرض قد لا تُظهر الوصف حتى عند تمكينه.';
$string['privacy:metadata'] = 'إن إضافة خارطة النشاط لا يخزن أي بيانات شخصية.';
$string['score'] = 'نتيجة';
$string['sectionbackgroundcolor'] = 'لون خلفية المقطع';
$string['this_is'] = 'هذا هو';
$string['transparent'] = 'شفاف';
