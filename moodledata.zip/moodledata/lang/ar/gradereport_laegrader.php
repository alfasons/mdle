<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'gradereport_laegrader', language 'ar', version '4.0'.
 *
 * @package     gradereport_laegrader
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['ajaxfieldchanged'] = 'الحقل الذي تقوم بتحريره حالياً قد تغير، هل ترغب باستعمال القيمة المحدثة؟';
$string['laegrader_columnwidth'] = 'عدد الحروف عرضيًا قبل التفاف عناوين التقديرات';
$string['showzerofill'] = 'إظهار الأيقونة التي تسمح بملء كل التقديرات الفارغة في هذا العمود بأصفار';
$string['zerofill'] = 'إملأ التقديرات الفارغة في هذا العمود بأصفار (لا يتم حفظ التغييرات تلقائياً)';
