<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'netucate', language 'ar', version '4.0'.
 *
 * @package     netucate
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['ActivityName'] = 'اسم النشاط';
$string['allroles'] = 'قائد الاجتماع/المرشد الرئيسي/قائد المؤتمر/تقني الغرفة';
$string['firstname'] = 'الاسم الأول';
$string['instructor_help'] = '<p>عبارة المرشد تستعمل كمرادف لـ:</p>
<ul>
<li>قائد الاجتماع في الاجتماعات</li>
<li>المرشد الرئيسي في الصفوف</li>
<li>قائد المؤتمر في المؤتمرات</li>
<li>تقني الغرفة في غرف الدعم</li>
</ul>';
$string['lastname'] = 'الاسم الأخير';
$string['netucateinstructordescription'] = 'يمكن للمرشد قيادة النشاط ولديه كل الصلاحيات';
$string['netucatename'] = 'اسم نشاط netucate';
$string['otherdurationmustbenumeric'] = 'قيمة الفترة الأخرى ينبغي أن تكون أكبر من 0.';
$string['participant'] = 'المشارك';
$string['roomtechnician'] = 'تقني الغرفة';
$string['support'] = 'غرفة الدعم';
