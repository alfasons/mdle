<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'videochat', language 'ar', version '4.0'.
 *
 * @package     videochat
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['advancedCamSettings'] = 'إعدادات الكامرة المتقدمة';
$string['desc'] = 'الوصف';
$string['fillWindow'] = 'إملأ النافذة';
$string['notallowenter'] = 'ليست لديك صلاحيات الوصول إلى هذه الغرفة';
$string['novideochat'] = 'لا توجد غرفة محادثة فيديوية في هذا المساق';
$string['open'] = 'الغرفة مفتوحة';
$string['room_limitdesc'] = 'تعيين أقصى حد للغرفة';
$string['room_limitlabel'] = 'حد الغرفة';
$string['rtmfpdesc'] = 'عنوان مخدم RTMFP';
$string['rtmpdesc'] = 'عنوان مخدم RTMP';
$string['videochat:view'] = 'الوصول إلى غرفة المحادثة الفيديوية';
$string['videochatname_help'] = 'يرجى إدخال الوصف الموجز لغرفة المحادثة الفيديوية.';
$string['videochatroomname'] = 'اسم غرفة المحادثة الفيديوية';
