<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'local_ganalytics', language 'ar', version '4.0'.
 *
 * @package     local_ganalytics
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['cachedef_global'] = 'الخبء العام لتحليلات Google';
$string['cachedef_session'] = 'خبء جلسة تحليلات Google';
$string['pluginname'] = 'تحليلات Google';
$string['privacy:externlink'] = 'تحليلات Google';
$string['privacy:metadata'] = 'لتحسين التقارير، يتم إرسال بيانات المستخدم إلى خدمة تحليلات خارجية.';
$string['privacy:metadata:coursename'] = 'تم إرسال اسم المساق بمثابة بُعد تقرير مخصص .';
$string['property_desc'] = 'إعدادات هذا الموقع في تحليلات Google';
$string['settingspage'] = 'إعدادات تحليلات Google';
