<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'filter_jwplayer', language 'ar', version '4.0'.
 *
 * @package     filter_jwplayer
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['enabledevents'] = 'توثيق الأحداث';
$string['eventmedia_audiotrack_switched'] = 'مسار صوت وسائط تم تبديله';
$string['eventmedia_captions_switched'] = 'مسار ترجمة وسائط تم تبديله';
$string['eventmedia_playback_completed'] = 'تشغيل وسائط تم إكماله';
$string['eventmedia_playback_failed'] = 'تشغيل وسائط فشل';
$string['eventmedia_playback_launched'] = 'تشغيل وسائط تم إطلاقه';
$string['eventmedia_playback_position_moved'] = 'موضع تشغيل وسائط تم نقله';
$string['eventmedia_playback_started'] = 'تشغيل وسائط تم البدء به';
$string['eventmedia_playback_stopped'] = 'تشغيل وسائط تم إيقافه';
$string['eventmedia_qualitylevel_switched'] = 'مستوى جودة وسائط تم تبديله';
$string['gaidstringdesc'] = 'الإجراء المراد تسجيله في تحليلات Google بالنسبة إلى تشغيل/إكمال الأحداث (مثلاً الملف أو العنوان). لمزيد من المعلومات، أانظر خيار التهيئة ga.idstring في التوثيقات التي في موقع مشغل JW.';
$string['galabeldesc'] = 'ملصق لتسجيله في تحليلات Google بالنسبة إلى أحداث المشغل (مثلاً الملف أو العنوان). لمزيد من المعلومات، أنظر خيار تهيئة ga.label في توثيقات مشغل JW في موقع الوب الخاص به.';
$string['googleanalytics'] = 'تكامل تحليلات Google';
$string['googleanalyticsconfig'] = 'تحليلات Google';
$string['googleanalyticsconfigdesc'] = 'يرجى الرجوع إلى التوثيقات التي في <a href="http://support.jwplayer.com/customer/portal/articles/1417179-integration-with-google-analytics">موقع مشغل JW</a> لمزيد من المعلومات عن التكامل مع تحليلات Google.';
$string['googleanalyticsdesc'] = 'تمكين التكامل مع تحليلات Google. يتطلب أن تكون النصوص البرمجية لتحليلات Google مضافة مسبقًا إلى الصفحات، يمكنك إضافتها باستعمال <a href="{$a}">المزيد من HTML</a> في إعدادات الموقع.';
