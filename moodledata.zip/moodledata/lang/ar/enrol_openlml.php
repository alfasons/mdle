<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_openlml', language 'ar', version '4.0'.
 *
 * @package     enrol_openlml
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['eventcohort_created'] = 'دفعة تم إنشاؤها';
$string['eventcohort_enroled'] = 'دفعة تم ضمها إلى مساق';
$string['eventcohort_member_added'] = 'عضو تمت إضافته إلى دفعة';
$string['eventcohort_member_removed'] = 'عضو تمت إزالته من دفعة';
$string['eventcohort_members_removed'] = 'أعضاء تمت إزالتهم من دفعة';
$string['eventcohort_removed'] = 'دفعة تمت إزالتها';
$string['eventcohort_unenroled'] = 'دفعة تم إلغاء ضمها إلى مقرر دراسي';
$string['eventteacher_role_assigned'] = 'دور معلم تم تعيينه في مساق';
$string['eventteacher_role_unassigned'] = 'دور معلم تم إلغاء تعيينه في مساق';
$string['students_settings'] = 'إعدادات الطلاب';
